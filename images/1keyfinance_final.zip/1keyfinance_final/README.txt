
1 Key Finance - Interactive Website Package (Two Themes)

Contents:
- index.html
- styles.css (common styles)
- theme-original.css (white + blue + light green theme)
- theme-rich.css (richer blue + gradient accents)
- script.js (interactive behavior)
- assets/ (placeholder SVG images & icons)
- README.txt (this file)

How to preview locally (Mac/Windows/Linux):
1. Extract the ZIP.
2. Open index.html directly in browser for a quick preview, OR run a local server:
   python3 -m http.server 8000
   then visit: http://localhost:8000

Notes:
- Placeholder images and avatars are included in /assets (SVGs). Replace them with real photos as needed.
- The theme toggle button switches between the two color themes on the fly.
- I cannot create an actual .fig Figma file here. I can however export PNG previews or provide detailed handoff notes for Figma recreation. If you'd like PNG previews of each page, tell me and I'll generate them.


document.getElementById('yr')?.textContent = new Date().getFullYear();

function scrollToSection(sel){
  const el = document.querySelector(sel);
  if(!el) return;
  el.scrollIntoView({behavior:'smooth', block:'start'});
}

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', function(){
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
    this.classList.add('active');
    const target = document.querySelector(this.dataset.target);
    if(target) target.classList.add('active');
  });
});

const themeToggle = document.getElementById('themeToggle');
let current = 'original';
themeToggle.addEventListener('click', ()=>{
  const link = document.getElementById('theme-link');
  if(current === 'original'){
    link.href = 'theme-rich.css';
    document.body.setAttribute('data-theme','rich');
    current = 'rich';
    themeToggle.textContent = 'Original Theme';
  } else {
    link.href = 'theme-original.css';
    document.body.setAttribute('data-theme','original');
    current = 'original';
    themeToggle.textContent = 'Richer Theme';
  }
});

let tIndex = 0;
const tests = document.querySelectorAll('.testimonial');
if(tests.length){
  tests[0].classList.add('active');
  setInterval(()=>{
    tests[tIndex].classList.remove('active');
    tIndex = (tIndex + 1) % tests.length;
    tests[tIndex].classList.add('active');
  },4500);
}

function calcSIP(){
  const m = Number(document.getElementById('sip_amount').value||0);
  const r = Number(document.getElementById('sip_rate').value||0);
  const years = Number(document.getElementById('sip_years').value||0);
  if(!m||!r||!years){ document.getElementById('sipResult').textContent='Enter valid inputs'; return; }
  const n = years * 12;
  const i = r / 1200;
  const fv = m * ( (Math.pow(1+i,n)-1) / i ) * (1+i);
  document.getElementById('sipResult').textContent = 'Estimated corpus: ₹' + Math.round(fv).toLocaleString();
}

document.getElementById('insQuote')?.addEventListener('submit', function(e){
  e.preventDefault();
  const type = document.getElementById('insType').value;
  const sum = Number(document.getElementById('insSum').value||0);
  const age = Number(document.getElementById('insAge').value||0);
  const base = type === 'Health' ? 0.02 : (type === 'Vehicle' ? 0.01 : 0.006);
  const ageFactor = age > 45 ? 1.4 : (age > 30 ? 1.15 : 1);
  const premium = Math.round(sum * base * ageFactor / 12);
  document.getElementById('insResult').textContent = 'Indicative monthly premium: ₹' + premium;
});

document.getElementById('contactForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  document.getElementById('contactResult').textContent = 'Message received. Our advisor will call you soon.';
  this.reset();
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('reveal');
    }
  });
},{threshold:0.15});
document.querySelectorAll('.card, .panel, .service').forEach(el => observer.observe(el));

document.addEventListener('DOMContentLoaded', ()=>{
  themeToggle.textContent = 'Switch Theme';
});
